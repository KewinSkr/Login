package com.example.login;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity

    {
    EditText naz1;

    EditText has1;

    Button log1;

    TextView log2;

    TextView has2;

    TextView nazwisko1;

    TextView imie;

    TextView imie2;

    TextView nazwisko2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity.main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        nazwisko2 = findViewById(R.id.naz1);

        has1 = findViewById(R.id.has1);

        imie = findViewById(R.id.imie);

        nazwisko2 = findViewById(R.id.nazwisko1);

        findViewById(R.id.log1);

        log1 = findViewById(R.id.log1);

        log2 = findViewById(R.id.log2);

        has2 = findViewById(R.id.has2);

        imie = findViewById(R.id.imie2);

        nazwisko2 = findViewById(R.id.nazwisko2);

        login.setOnClickListener(log1 -> {
            log2.setText(nazwa.getText());
            has2.setText(haslo.getText());
            im.setText(imie.getText());
            nazwisko2.setText(nazwisko2.getText());

        });
        has1.getText();
    }
}